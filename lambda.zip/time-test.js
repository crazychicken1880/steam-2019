var time = 84.57

function format_as_time(t) {

    // var minutes = Math.floor(t / 60)
    // var seconds = t - minutes * 60
    // if (seconds < 10) {
    //     if (minutes >= 1) {
    //         return minutes + " minutes and " + seconds.toFixed(2) + ' seconds'
    //     } if (minutes < 1) { return seconds.toFixed(2) + ' seconds' }
    // } if (minutes < 1) { return seconds.toFixed(2) + ' seconds' }
    //  if (minutes < 1) { return seconds.toFixed(2) + ' seconds' }}
    // else {
    //     return minutes + ' minute and ' + seconds.toFixed(2) + ' seconds'
    // }
}

// console.log(format_as_time(60))

