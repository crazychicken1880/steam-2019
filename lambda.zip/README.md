# Steam Project

## Questions to Answer

1. What is the {medal} time for {gender} {age} {stroke}? (Given a medal and scope provide a time)
2. What is the {medal} time is {my_time} for {gender} {age} {stroke}? (Given a time and scope provide a medal)
3. How close is {time} to a {medal} for {gender} {age} {stroke}? (Given a time, a medal and a scope provide a difference in seconds)

| Slot | Values |
| ------ | ----------| 
| Medal | Gold, Silver, Bronze | 
| Age Group | 6u, 7-8, 9-10, 11-12, 13-14, 15-18 |
| Stroke | Free, Breast, Back, Fly, IM |
| Distance | 25, 50, 100 |
| Gender | Girls, Boys |

alexa ask swim skill what is a gold time for boys seven eight breast



Samples 

TimeStandardIntent

alexa ask swim skill what is the bronze time for seven eight girls 25 fly

alexa ask swim skill what is the gold time for nine ten boy 50 breast

alexa ask swim skill what is the silver time for fifteen eighteen boys 100 free

MedalTypeIntent

alexa ask swim skill what medal is the time forty three point eleven seconds for nine ten boys 50 breast

alexa ask swim skill what medal is the time 1 minute seventeen point zero seconds for seven eight girls 50 fly

alexa ask swim skill what medal is the time 3 minutes 10 point 12 seconds for eleven twelve girls 50 fly

TimePopIntent

alexa ask swim skill how much time from two mimutes forty eight point eleven seconds to a gold time for nine ten boys 50 breast

alexa ask swim skill how much time from fifty eight point twenty two seconds to a silver time for nine ten boys 50 breast

alexa ask swim skill 
